// function MyCountryCard.jsx() {
//     return (
//         <div className="MyCountryCardContainer">
//             <img src={country.flags.png} alt={`Image of ${country.name.common}`} />
//             <div className="CountryDetails">
//                 <h2>{country.name.common}</h2>
//                 <p>Population: {country.population}</p>
//                 <p>Region: {country.region}</p>
//                 <p>Capital: {country.capital}</p>
//                 <p>Search For: XX times</p>
//             </div>
//             <div className="BorderCountries">
//                 <h4>Border Countries:</h4>
//                 <span>Some Country</span>
//                 <span>Some Country</span>
//             </div>
//         </div>
//     );
// };